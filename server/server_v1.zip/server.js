const express = require('express');
const app = express();
const mysql = require('mysql');
const bodyParser = require('body-parser');

app.use(bodyParser.json());

console.log('host: ',process.env.HOST,
  'user: ',process.env.USER,
  'password: ',process.env.PASSWORD,
  'database: ',process.env.DATABASE);

// Configura la conexión a la base de datos
const db = mysql.createConnection({
  host: process.env.HOST,
  user: process.env.USER,
  password: process.env.PASSWORD,
  database: process.env.DATABASE
});

db.connect(err => {
  if (err) {
    console.error('Error de conexión a la base de datos:', err);
  } else {
    console.log('Conexión a la base de datos exitosa');
  }
});

// Configura una ruta para recibir datos del formulario
app.post('/api/registrar', (req, res) => {
  const { name, email } = req.body; // Datos del formulario

  // Realiza la inserción en la base de datos
  const sql = 'INSERT INTO usuarios (name, email) VALUES (?, ?)';
  db.query(sql, [name, email], (err, result) => {
    if (err) {
      console.error('Error al insertar datos en la base de datos:', err);
      res.status(500).json({ error: 'Error al insertar datos' });
    } else {
      console.log('Datos insertados con éxito');
      res.status(200).json({ message: 'Datos insertados con éxito' });
    }
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Servidor backend en ejecución en el puerto ${port}`);
});
